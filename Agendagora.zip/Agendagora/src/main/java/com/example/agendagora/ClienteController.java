package com.example.agendagora;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class ClienteController implements Initializable {
    @FXML
    TableView<Cliente> tabelaCliente;

    @FXML
    TableColumn<Cliente, Integer> colunaCodigo;

    @FXML
    TableColumn<Cliente, String> colunaNome;

    @FXML
    TableColumn<Cliente, String> colunaEndereco;

    @FXML
    TableColumn<Cliente, String> colunaTelefone;
    @FXML
    ImageView voltar;


    //configura as colunas da na interface grafica

    public void initialize(URL url, ResourceBundle resourceBundle) {
        colunaCodigo.setCellValueFactory(new PropertyValueFactory<>("codigo"));
        colunaNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colunaEndereco.setCellValueFactory(new PropertyValueFactory<>("endereco"));
        colunaTelefone.setCellValueFactory(new PropertyValueFactory<>("telefone"));


        Cliente cliente1 = new Cliente();
        cliente1.codigo = 1;
        cliente1.nome = "Roberto Debarba";
        cliente1.endereco = "Rua Blumenau 666 - Timbó";
        cliente1.telefone = "47 9 9948-4130";

        Cliente cliente2 = new Cliente();
        cliente2.codigo = 2;
        cliente2.nome = "José Carlos da Silva";
        cliente2.endereco = "Rua Carandiru 777 - Indaial";
        cliente2.telefone = "47 9 9972-7371";


        tabelaCliente.getItems().add(cliente1);
        tabelaCliente.getItems().add(cliente2);


    }

    public void novo() throws IOException {
        CadastroClienteController.cliente=null;
        AgendaApplication.showModal("cadastro-cliente-view");
        Cliente novocliente= CadastroClienteController.cliente;
        if (novocliente!= null) {
            tabelaCliente.getItems().add(CadastroClienteController.cliente);
        }
    }
    public void editar() throws IOException {
        Cliente clienteselecionado= tabelaCliente.getSelectionModel().getSelectedItem();

        CadastroClienteController.cliente= clienteselecionado;

        AgendaApplication.showModal("cadastro-cliente-view");

        Cliente clienteeditado = CadastroClienteController.cliente;

        clienteselecionado.codigo=clienteeditado.codigo;
        clienteselecionado.nome=clienteeditado.nome;
        clienteselecionado.endereco=clienteeditado.endereco;
        clienteselecionado.telefone=clienteeditado.telefone;

        tabelaCliente.refresh();
    }
    @FXML
    public void excluir() {
        Cliente clienteselecionado = tabelaCliente.getSelectionModel().getSelectedItem();

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Excluir Cliente");
        alert.setHeaderText(null);
        alert.setContentText("Deseja excluir" + " " + clienteselecionado.nome+ " "+"?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            tabelaCliente.getItems().remove(clienteselecionado);
        }
    }

    public void voltar() throws IOException {

        AgendaApplication.setRoot("menu-principal-view");




    }
}

