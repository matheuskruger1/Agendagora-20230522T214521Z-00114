package com.example.agendagora;

public class Usuario {
    public int codigo;
    public String usuario;
    public String senha;

    public Usuario(String usuario, String senha){
        this.usuario=usuario;
        this.senha=senha;

    }
}
