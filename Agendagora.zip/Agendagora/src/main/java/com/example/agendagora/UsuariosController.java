package com.example.agendagora;

import java.io.IOException;

public class UsuariosController {
    public void voltar() throws IOException {
        AgendaApplication.setRoot("configuracoes-view");
    }
}
