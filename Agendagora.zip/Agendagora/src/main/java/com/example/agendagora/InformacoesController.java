package com.example.agendagora;

import java.io.IOException;

public class InformacoesController {
    public void voltar() throws IOException {
        AgendaApplication.setRoot("configuracoes-view");
    }
}
